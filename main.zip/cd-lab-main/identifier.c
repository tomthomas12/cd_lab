#include <stdio.h>
#include <ctype.h>

int main() {
  char input[100];
  int flag;

  printf("Input string: ");
  scanf("%s", input);

  for (int i = 0; input[i] != '\0'; i++) {
    if (i == 0 && isalpha(input[0]) || input[0] == '_') flag = 1;
    if (!isdigit(input[i]) && !isalpha(input[i]) && input[i] != '_') {
      flag = 0;
      break;
    }
  }

  if (flag) printf("%s is a valid identifier", input);
  else printf("%s is not a valid identifier", input);

  return 0;
}
