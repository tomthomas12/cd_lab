#include <stdio.h>
#include <string.h>

void main()
{
    char icode[10][30],str[20],opr[10];
    int i=0;
    printf("\nEnter the set of intermediate code\n");
    do {
        scanf("%s",icode[i]);
    } while(strcmp(icode[i++],"exit") != 0);
    printf("\ntarget code generation\n");
    i=0;
    do
    {
        strcpy(str,icode[i]);

        switch(str[3])
        {
            case '+': strcpy(opr,"add");
            break;
            case '-': strcpy(opr,"sub");
            break;
            case '*': strcpy(opr,"mul");
            break;
            case '/': strcpy(opr,"div");
            break;
        }

        printf("\nmov %c,R%d",str[2],i);
        printf("\n%s %c,R%d",opr,str[4],i);
        printf("\nmov R%d,%c",i,str[0]);

    } while(strcmp(icode[++i],"exit")!=0);
}
