#include <stdio.h>
#include <string.h>

int main() {
  int i, input_size, max_size = 100, flag = 0;
  char input[max_size], * result;

  puts("Input string: ");
  fgets(input, max_size, stdin);

  input_size = strlen(input) - 1;

  for (i = 0; input[i] == 'a'; i++);
  for (; input[i] == 'b'; i++);

  if (input[i] == '\n' && i == input_size) flag = 1;

  if (flag) result = "Input string is accepted under the rule 'a* / a*b+ / abb'";
  else result = "Input string is rejected under the rule 'a* / a*b+ / abb'";

  puts(result);

  return 0;
}
