#include <stdio.h>
#include <string.h>
#include <math.h>

int main() {
  int st, fin, in, i, j, curr, p, q, r, rel, flag = 0;
  int dfa[100][2][100], state[1000], go[1000][2], arr[1000], f[10];
  char str[1000];

  printf("Number of states: ");
  scanf("%d", &st);

  for (i = 0; i < st; i++) state[(int) (pow(2, i))] = 1;

  printf("Number of final states: ");
  scanf("%d", &fin);

  printf("Final states: ");
  for (i = 0; i < fin; i++) scanf("%d", &f[i]);

  printf("Number of rules according to NFA: ");
  scanf("%d", &rel);

  printf("\nInput transition rules as 'INITIAL-STATE INPUT-SYMBOL FINAL-STATE'\n");

  for (i = 0; i < rel; i++) {
    scanf("%d %d %d", &p, &q, &r);

    if (!q) dfa[p][0][r] = 1;
    else dfa[p][1][r] = 1;
  }

  printf("\nInitial state: ");
  scanf("%d", &in);

  in = pow(2, in);

  printf("\nSolving according to DFA\n");

  int x = 0;

  for (i = 0; i < st; i++) {
    for (j = 0; j < 2; j++) {
      int stf = 0;

      for (int k = 0; k < st; k++)
        if (dfa[i][j][k] == 1)
          stf = stf + pow(2, k);

      go[(int) (pow(2, i))][j] = stf;

      printf("%d - %d --> %d\n", (int) (pow(2, i)), j, stf);

      if (state[stf] == 0) arr[x++] = stf;

      state[stf] = 1;
    }
  }

  for (i = 0; i < x; i++) {
    for (j = 0; j < 2; j++) {
      int new = 0;

      for (int k = 0; k < st; k++) {
        if (arr[i] & (1 << k)) {
          int h = pow(2, k);
          new = go[h][j];
        }
      }

      if (!state[new]) {
        arr[x++] = new;
        state[new] = 1;
      }
    }
  }

  printf("\nNumber of distinct states are:\n");
  printf("STATE 0 1\n");

  for (i = 0; i < 1000; i++) {
    if (state[i] == 1) {
      int y = 0;

      if (!i) printf("q0    ");
      else {
        for (j = 0; j < st; j++) {
          int x = 1 << j;

          if (x & i) {
            printf("q%d    ", j);
            y = y + pow(2, j);
          }
        }
      }

      printf("%d %d\n", go[y][0], go[y][1]);
    }
  }

  j = 3;

  while (j--) {
    printf("\nEnter the string: ");
    scanf("%s", str);

    int l = strlen(str);

    curr = in;
    flag = 0;

    printf("String takes the path: ");
    printf("%d", curr);

    for (i = 0; i < l; i++) {
      printf(" -> ");
      curr = go[curr][str[i] - '0'];
      printf("%d", curr);
    }

    printf("\nFinal state: %d\n", curr);

    for (i = 0; i < fin; i++) {
      if (curr & (1 << f[i])) {
        flag = 1;
        break;
      }
    }

    if (flag) printf("String is accepted.\n");
    else printf("String is rejected.\n");
  }

  return 0;
}
