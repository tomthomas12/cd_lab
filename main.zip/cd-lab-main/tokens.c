#include <stdio.h>
#include <ctype.h>
#include <string.h>

int cursor = 0, keywords = 0, identifiers = 0, constants = 0, operators = 0;

void check(char* pattern) {
  char* keys[32] = {
    "auto","break","case","char","const","continue","default", "do",
    "double","else","enum","extern","float","for","goto","if", "int",
    "long","register","return","short","signed","sizeof","static","struct",
    "switch","typedef","union","unsigned","void","volatile","while"
  };

  int flag = 0;

  for (int i = 0; i < 32; i++) {
    if (strcmp(keys[i], pattern) == 0) {
      printf("%s\t\t  keyword\n", pattern);
      keywords++;
      flag = 1;
      break;
    }
  }

  if (flag == 0) {
    if (isdigit(pattern[0])) {
      printf("%s\t\t  constant\n", pattern);
      constants++;
    }
    else if (pattern[0] != '\0') {
      printf("%s\t\t  identifier\n", pattern);
      identifiers++;
    }
  }

  cursor = -1;
}

int main(int argc, char** argv) {
  char ch, str[25], * seperators = " \t\n,;(){}[]#\"<>", * ops = "!%^&*-+=~|.<>/?";

  if (argc < 2) return -1;

  FILE* f = fopen(argv[1], "r");

  while ((ch = fgetc(f)) != EOF) {
    for (int i = 0; i <= 14; i++) {
      if (ch == ops[i]) {
        printf("%c\t\t  operator\n", ch);
        operators++;
        str[cursor] = '\0';
        check(str);
      }
    }

    for (int i = 0; i < 15; i++) {
      if (cursor == -1) break;
      if (ch == seperators[i]) {
        if (ch == '#') {
          while (ch != '\n') {
            printf("%c", ch);
            ch = fgetc(f);
          }
          printf(" directive\n");
          cursor = -1;
          break;
        }
        if (ch == '"') {
          do {
            ch = fgetc(f);
            printf("%c", ch);
          } while (ch != '"');
          printf("\t\t  literal\n");
          cursor = -1;
          break;
        }
        str[cursor] = '\0';
        check(str);
      }

    }
    if (cursor != -1) {
      str[cursor] = ch;
      cursor++;
    }
    else cursor = 0;
  }
  printf("\nkeywords: %d\nidentifiers: %d\noperators: %d\nconstants: %d\n", keywords, identifiers, operators, constants);

  return 0;
}
