#include <stdio.h>
#include <string.h>

int main() {
  int input_size, max_size = 100, flag = 0;
  char input[max_size], * result;

  puts("Input string: ");
  fgets(input, max_size, stdin);

  input_size = strlen(input);

  if (input[0] == '/'
    && (input[1] == '/'
      || (input[1] == '*'
        && input[input_size - 3] == '*'
        && input[input_size - 2] == '/'))) flag = 1;

  if (flag) result = "Input string is a comment.";
  else result = "Input string is not a comment.";

  puts(result);

  return 0;
}
